import { isAuthorized,configurationError,securityHeaders } from './_auth.mjs';
export default async request=>{const ce=configurationError();if(ce)return ce;return Response.json({authenticated:isAuthorized(request)},{headers:securityHeaders()})};
