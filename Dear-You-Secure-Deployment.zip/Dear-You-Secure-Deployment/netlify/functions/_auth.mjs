import { createHmac, timingSafeEqual } from 'node:crypto';
const COOKIE='dearyou_admin_session'; const MAX_AGE=60*60*8;
function secret(){return process.env.DY_SESSION_SECRET||'';}
function sign(value){return createHmac('sha256',secret()).update(value).digest('base64url');}
export function cookieHeader(value,maxAge=MAX_AGE){return `${COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;}
export function clearCookie(){return cookieHeader('',0);}
export function makeSession(){const exp=String(Math.floor(Date.now()/1000)+MAX_AGE);return `${exp}.${sign(exp)}`;}
export function isAuthorized(request){if(!secret()||secret().length<32)return false;const raw=request.headers.get('cookie')||'';const pair=raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(`${COOKIE}=`));if(!pair)return false;const token=pair.slice(COOKIE.length+1).split('.');if(token.length!==2||!/^\d+$/.test(token[0])||Number(token[0])<Math.floor(Date.now()/1000))return false;const expected=Buffer.from(sign(token[0]));const actual=Buffer.from(token[1]);return expected.length===actual.length&&timingSafeEqual(expected,actual);}
export function originAllowed(request){const origin=request.headers.get('origin');if(!origin)return false;try{const a=new URL(origin),b=new URL(request.url);return a.host===b.host&&a.protocol===b.protocol;}catch{return false;}}
export function securityHeaders(){return {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'DENY','Vary':'Cookie'};}
export function configurationError(){if(!process.env.DY_ADMIN_PASSWORD||process.env.DY_ADMIN_PASSWORD.length<14||!secret()||secret().length<32)return Response.json({error:'Author sign-in is not configured. The site owner must set DY_ADMIN_PASSWORD (at least 14 characters) and DY_SESSION_SECRET (at least 32 random characters) in Netlify environment variables, then redeploy.'},{status:503,headers:securityHeaders()});return null;}
